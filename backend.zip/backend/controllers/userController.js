const pool = require("../config/db");
const bcrypt = require("bcrypt");

exports.getAllUsers = async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT
      user_serial_no,
      user_code,
      first_name,
      last_name,
      email,
      phone,
      role_id,
      company_id,
      is_active
      FROM users
      ORDER BY user_serial_no
    `);

    res.json(result.rows);
  } catch (error) {
    console.log(error);
    res.status(500).json({ message: error.message });
  }
};

exports.getUserByCode = async (req, res) => {
  try {
    const { userCode } = req.params;

    const result = await pool.query(
      `SELECT * FROM users WHERE user_code=$1`,
      [userCode]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        message: "User not found",
      });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.log(error);
    res.status(500).json({ message: error.message });
  }
};

exports.createUser = async (req, res) => {
  try {
    const {
      company_id,
      role_id,
      user_code,
      first_name,
      last_name,
      email,
      password,
      phone,
    } = req.body;

    const hash = await bcrypt.hash(password, 10);

    const result = await pool.query(
      `
      INSERT INTO users
      (
        company_id,
        role_id,
        user_code,
        first_name,
        last_name,
        email,
        password_hash,
        phone
      )
      VALUES
      ($1,$2,$3,$4,$5,$6,$7,$8)
      RETURNING *
      `,
      [
        company_id,
        role_id,
        user_code,
        first_name,
        last_name,
        email,
        hash,
        phone,
      ]
    );

    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.log(error);
    res.status(500).json({ message: error.message });
  }
};

exports.updateUser = async (req, res) => {
  try {
    const { userCode } = req.params;

    const {
      first_name,
      last_name,
      phone,
      role_id,
      is_active,
    } = req.body;

    const result = await pool.query(
      `
      UPDATE users
      SET
      first_name=$1,
      last_name=$2,
      phone=$3,
      role_id=$4,
      is_active=$5,
      update_timestamp=CURRENT_TIMESTAMP
      WHERE user_code=$6
      RETURNING *
      `,
      [
        first_name,
        last_name,
        phone,
        role_id,
        is_active,
        userCode,
      ]
    );

    res.json(result.rows[0]);
  } catch (error) {
    console.log(error);
    res.status(500).json({ message: error.message });
  }
};

exports.deleteUser = async (req, res) => {
  try {
    const { userCode } = req.params;

    await pool.query(
      `
      DELETE FROM users
      WHERE user_code=$1
      `,
      [userCode]
    );

    res.json({
      message: "User deleted successfully",
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({ message: error.message });
  }
};