const pool = require("../config/db");

exports.createTicket = async (req, res) => {
  try {
    const {
      company_id,
      ticket_no,
      subject,
      description,
      category_id,
      priority_id,
      status_id,
      raised_by_user_code,
      assigned_to_user_code,
    } = req.body;

    const result = await pool.query(
      `
      INSERT INTO tickets
      (
        company_id,
        ticket_no,
        subject,
        description,
        category_id,
        priority_id,
        status_id,
        raised_by_user_code,
        assigned_to_user_code
      )
      VALUES
      ($1,$2,$3,$4,$5,$6,$7,$8,$9)
      RETURNING *
      `,
      [
        company_id,
        ticket_no,
        subject,
        description,
        category_id,
        priority_id,
        status_id,
        raised_by_user_code,
        assigned_to_user_code,
      ]
    );

    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.log(error);
    res.status(500).json({ message: error.message });
  }
};

exports.getTickets = async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT tickets.*, ticket_statuses.status_name
      FROM tickets INNER JOIN ticket_statuses
      ON tickets.status_id = ticket_statuses.status_id
      ORDER BY ticket_id DESC
    `);

    res.json(result.rows);
  } catch (error) {
    console.log(error);
    res.status(500).json({ message: error.message });
  }
};

exports.getTicketById = async (req, res) => {
  try {
    const { id } = req.params;

    const result = await pool.query(
      `
      SELECT *
      FROM tickets
      WHERE ticket_id=$1
      `,
      [id]
    );

    res.json(result.rows[0]);
  } catch (error) {
    console.log(error);
    res.status(500).json({ message: error.message });
  }
};

exports.updateTicket = async (req, res) => {
  try {
    const { id } = req.params;

    const {
      subject,
      description,
      priority_id,
      status_id,
      assigned_to_user_code,
    } = req.body;

    const result = await pool.query(
      `
      UPDATE tickets
      SET
      subject=$1,
      description=$2,
      priority_id=$3,
      status_id=$4,
      assigned_to_user_code=$5,
      update_timestamp=CURRENT_TIMESTAMP
      WHERE ticket_id=$6
      RETURNING *
      `,
      [
        subject,
        description,
        priority_id,
        status_id,
        assigned_to_user_code,
        id,
      ]
    );

    res.json(result.rows[0]);
  } catch (error) {
    console.log(error);
    res.status(500).json({ message: error.message });
  }
};

exports.deleteTicket = async (req, res) => {
  try {
    const { id } = req.params;

    await pool.query(
      `
      DELETE FROM tickets
      WHERE ticket_id=$1
      `,
      [id]
    );

    res.json({
      message: "Ticket deleted successfully",
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({ message: error.message });
  }
};