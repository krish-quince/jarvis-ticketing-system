const pool = require("../config/db");

exports.getCategories =
async (req, res) => {

  try {

    const result =
      await pool.query(`
        SELECT
          category_id,
          category_name
        FROM ticket_categories
        WHERE is_active = true
        ORDER BY category_name
      `);

    res.json(result.rows);

  } catch (error) {

    console.error(error);

    res.status(500).json({
      message:
        "Failed to fetch categories",
    });
  }
};