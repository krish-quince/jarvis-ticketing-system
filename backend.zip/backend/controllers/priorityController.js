const pool = require("../config/db");

exports.getPriorities = async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT
        priority_id,
        priority_name
      FROM ticket_priorities
      ORDER BY priority_value
    `);

    res.json(result.rows);
  } catch (error) {
    console.error(error);

    res.status(500).json({
      message: "Failed to fetch priorities",
    });
  }
};