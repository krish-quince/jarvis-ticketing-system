const pool = require("../config/db");

exports.getTags = async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT
        tag_id,
        tag_name
      FROM tags
      WHERE is_active = true
      ORDER BY tag_name
    `);

    res.json(result.rows);
  } catch (error) {
    console.error(error);

    res.status(500).json({
      message: "Failed to fetch tags",
    });
  }
};
