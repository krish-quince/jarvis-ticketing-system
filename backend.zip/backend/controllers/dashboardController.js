const pool = require("../config/db");

exports.getDashboardSummary = async (req, res) => {
  try {

    const totalTickets = await pool.query(
      `SELECT COUNT(*) FROM tickets`
    );

    const openTickets = await pool.query(
      `
      SELECT COUNT(*)
      FROM tickets t
      JOIN ticket_statuses ts
      ON t.status_id = ts.status_id
      WHERE ts.status_name='Open'
      `
    );

    const inProgressTickets = await pool.query(
      `
      SELECT COUNT(*)
      FROM tickets t
      JOIN ticket_statuses ts
      ON t.status_id = ts.status_id
      WHERE ts.status_name='In Progress'
      `
    );

    const closedTickets = await pool.query(
      `
      SELECT COUNT(*)
      FROM tickets t
      JOIN ticket_statuses ts
      ON t.status_id = ts.status_id
      WHERE ts.status_name='Closed'
      `
    );

    res.json({
      totalTickets:
        totalTickets.rows[0].count,

      openTickets:
        openTickets.rows[0].count,

      inProgressTickets:
        inProgressTickets.rows[0].count,

      closedTickets:
        closedTickets.rows[0].count,
    });

  } catch (error) {

    res.status(500).json({
      message: error.message,
    });

  }
};