const express = require("express");

const router = express.Router();

const {
  getPriorities,
} = require("../controllers/priorityController");

router.get("/", getPriorities);

module.exports = router;